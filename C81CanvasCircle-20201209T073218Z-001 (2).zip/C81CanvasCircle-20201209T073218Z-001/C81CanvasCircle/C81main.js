Canvas = document.getElementById("canvas");
ctx = Canvas.getContext("2d");

color = "blue";

ctx.beginPath();
ctx.strokeStyle = color;
ctx.lineWidth = 6;
ctx.arc(200,200,70,0, 2*Math.PI);
ctx.stroke();

color = "yellow";

ctx.beginPath();
ctx.strokeStyle = color;
ctx.lineWidth = 6;
ctx.arc(310,260,70,0, 2*Math.PI);
ctx.stroke();

color = "black";
ctx.beginPath();
ctx.strokeStyle = color;
ctx.lineWidth = 6;
ctx.arc(420,200,70,0, 2*Math.PI);
ctx.stroke();

color = "brown";
ctx.beginPath();
ctx.strokeStyle = color;
ctx.lineWidth = 6;
ctx.arc(520,260,70,0, 2*Math.PI);
ctx.stroke();

color = "red";
ctx.beginPath();
ctx.strokeStyle = color;
ctx.lineWidth = 6;
ctx.arc(620,200,70,0, 2*Math.PI);
ctx.stroke();

Canvas.addEventListener("mousedown",mouse_d);

function mouse_d(l)
{
    mouse_X = l.clientX - Canvas.offsetLeft;
    mouse_Y = l.clientY - Canvas.offsetTop;

    console.log("X = " + mouse_X +", Y = " + mouse_Y);
    circle(mouse_X,mouse_Y);


}

function circle(mouse_X,mouse_Y)
{
    ctx.beginPath();
    ctx.strokeStyle = color;
    ctx.lineWidth = 3;
    ctx.arc(mouse_X,mouse_Y,70,0, 2*Math.PI);
    ctx.stroke();
      
}